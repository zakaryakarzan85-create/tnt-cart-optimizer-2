# TNT Cart Optimizer

A **client-side-only** Fabric mod for Minecraft 26.2 with two features:

1. **TNT Minecart placement optimization** — reduces unnecessary *client-side*
   input delay when placing TNT Minecarts, so on high-ping servers there's
   less lag between one placement click and the next.
2. **TNT Minecart overlap warning** — shows a large `!` in the center of the
   screen whenever 2 or more TNT Minecarts are occupying essentially the same
   spot. Press **J** to open a settings screen and resize the warning.

Only TNT Minecarts are affected. Normal minecarts and every other item are
left completely untouched.

---

## What it does *not* do

This is a UI/input-pacing optimization, not a gameplay exploit:

- It never sends extra network packets and never changes what packet is sent.
- It never causes the server to accept a placement it would otherwise reject.
  The server is, and remains, fully authoritative.
- It doesn't touch normal minecarts or any other item.
- The overlap warning is purely visual — no chat messages, no sounds, no
  particles.

See [`MinecraftClientMixin.java`](src/client/java/com/tntcartopt/mixin/MinecraftClientMixin.java)
for exactly what the placement optimization does and why: it only shortens a
short **client-only** pacing timer (`rightClickDelayTimer`) that vanilla
already resets to `0` before checking a lock. Nothing about the server or the
network protocol is changed.

## How the optimization works

Independently of anything the server checks, the vanilla client keeps its own
short cooldown after each right-click "use item" interaction, so that holding
the mouse button down isn't treated as several instant clicks. That is a
purely local, client-side UX safeguard — on a connection with real ping, it
stacks on top of network latency, so a player who is genuinely clicking once
per cart still feels extra delay that has nothing to do with the server.

`MinecraftClientMixin` shortens that timer back to `0` on the client's own
tick, but **only** while the currently held item is a TNT Minecart. Every
other item — including a plain Minecart — keeps vanilla's untouched timing.

## How the overlap warning works

Once per client tick, `TntOverlapWarningHud` gathers every `MinecartTNT`
entity the client currently knows about near the player and checks each pair
of them against a distance threshold. If any two are within that distance,
a flag is set and the HUD draws `!` at the configured size until no pair is
within the threshold anymore.

The distance threshold is a single constant, deliberately easy to find and
change:

```java
// src/client/java/com/tntcartopt/hud/TntOverlapWarningHud.java
public static final double OVERLAP_DISTANCE_THRESHOLD = 0.5D;
```

## Configuring the warning size

- Press **J** in-game to open **TNT Cart Optimizer Settings**.
- **`-`** / **`+`** shrink/grow the warning in steps of `0.5×`.
- **Reset** restores the default (`5.0×`).
- **Done** saves your choice to `config/tntcartopt.json` and closes the
  screen (pressing Escape also saves).
- The size is clamped between `1.0×` and `15.0×` and is loaded automatically
  the next time Minecraft starts. These bounds and the step size are
  constants at the top of
  [`ModConfig.java`](src/client/java/com/tntcartopt/config/ModConfig.java).

The J keybinding can be rebound normally from *Options → Controls → Key
Binds → TNT Cart Optimizer*.

---

## Project layout

```
tnt-cart-optimizer/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── src/
│   ├── main/resources/
│   │   └── fabric.mod.json
│   └── client/                                # this mod is 100% client code
│       ├── java/com/tntcartopt/
│       │   ├── TntCartOptimizerClient.java     # client entrypoint
│       │   ├── config/
│       │   │   ├── ModConfig.java              # size bounds/default/step
│       │   │   └── ConfigManager.java          # load/save JSON
│       │   ├── gui/
│       │   │   └── CartOptimizerConfigScreen.java
│       │   ├── hud/
│       │   │   └── TntOverlapWarningHud.java   # detection + HUD draw
│       │   ├── mixin/
│       │   │   └── MinecraftClientMixin.java   # the placement optimization
│       │   └── util/
│       │       └── TntMinecartUtil.java        # single "is this TNT?" check
│       └── resources/
│           ├── tntcartopt.mixins.json
│           └── assets/tntcartopt/lang/en_us.json
```

`fabric.mod.json` sets `"environment": "client"`, so Fabric Loader refuses
to load this mod at all on a dedicated server — there is intentionally no
"main"/common entrypoint.

---

## Requirements

- **Minecraft 26.2** (Java Edition)
- **Java 25** (JDK) to build; the Minecraft launcher bundles a matching
  runtime to *play*
- **Fabric Loader** ≥ 0.19.3
- **Fabric API** `0.154.2+26.2`
- **Fabric Loom** `1.17` (pulled in automatically by Gradle) and **Gradle
  9.5.1** (via the wrapper)

Minecraft 26.2 ships unobfuscated with real (Mojang) names already applied,
so — unlike older Minecraft versions — this project does **not** declare a
separate `mappings` dependency; `build.gradle` intentionally has none.

## Building

```bash
git clone <this project>
cd tnt-cart-optimizer
./gradlew build
```

The built mod jar will be in `build/libs/tnt-cart-optimizer-1.0.0.jar`.

> **No Gradle wrapper jar included.** This project ships
> `gradle/wrapper/gradle-wrapper.properties` (pointing at Gradle 9.5.1) but
> not the `gradle-wrapper.jar` binary itself. Generate it once with any
> local Gradle install:
> ```bash
> gradle wrapper --gradle-version 9.5.1
> ```
> or simply open the folder in IntelliJ IDEA with the Fabric/Minecraft
> Development plugins — it will offer to set up Gradle for you. This is
> exactly how Fabric's own template projects work.

To launch a dev client directly instead of building a jar:

```bash
./gradlew runClient
```

## Installing the built mod

1. Install [Fabric Loader](https://fabricmc.net/use/) for Minecraft 26.2.
2. Download [Fabric API](https://modrinth.com/mod/fabric-api) `0.154.2+26.2`
   (or newer for 26.2) into your `mods` folder — this mod depends on it.
3. Copy `tnt-cart-optimizer-1.0.0.jar` from `build/libs/` into your
   `.minecraft/mods` folder.
4. Launch Minecraft using the Fabric profile.

---

## A note on verification

This project was written and reasoned through carefully against Fabric's
current (26.2-tagged) official documentation and the real `fabric-example-mod`
source, but it was **not compiled against the actual Minecraft/Fabric jars**
— the environment used to write this had no network access to download
them, so there was no `javac`/Gradle build available to verify it end to
end. Everything here reflects that research as closely as possible, but
because Minecraft 26.2 is very recent, treat the first build like you would
any freshly-ported mod: build it, and if Gradle/your IDE flags an import,
it's almost always a one-click "quick fix"/auto-import away from correct.
A few specific spots are the most likely to need that:

- **`MinecraftClientMixin`** targets `Minecraft#tick()` and shadows the
  `rightClickDelayTimer` field. Both names are long-standing in Minecraft's
  own client code, but if Loom/Mixin reports either one missing, open
  `Minecraft` via IntelliJ's "Go to Class" (after running the IDE's
  "Generate Sources" step) and look for the per-tick method and the small
  `int` field that gates repeated right-click interactions — update the
  `method = "..."` string or the `@Shadow` field name to match.
- A couple of import paths were inferred rather than directly confirmed
  from source: `com.mojang.blaze3d.platform.InputConstants`,
  `net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper`, and
  `net.minecraft.util.Identifier`. If any of these don't resolve, your
  IDE's auto-import (there's normally only one real candidate) will find
  the actual package instantly.

Everything else — the Gradle setup, `fabric.mod.json`, the mixin config,
`HudElementRegistry`/`GuiGraphicsExtractor` usage, and the `KeyMapping`/
`Screen`/`Button` API — was checked directly against Fabric's official,
version-tagged ("26.2") documentation and the real `fabric-example-mod`
repository.

## Customizing

- **Overlap distance**: `OVERLAP_DISTANCE_THRESHOLD` in `TntOverlapWarningHud.java`.
- **Search radius** around the player for overlap checks: `SEARCH_RADIUS` in
  the same file.
- **Size bounds/default/step**: `MIN_SCALE` / `MAX_SCALE` / `DEFAULT_SCALE` /
  `SCALE_STEP` in `ModConfig.java`.
- **Warning color**: `WARNING_COLOR` in `TntOverlapWarningHud.java` (ARGB —
  keep the leading `0xFF` for full opacity).
