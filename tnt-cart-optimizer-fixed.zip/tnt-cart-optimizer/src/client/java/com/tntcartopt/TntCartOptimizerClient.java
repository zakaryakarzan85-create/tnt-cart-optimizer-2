package com.tntcartopt;

import com.mojang.blaze3d.platform.InputConstants;
import com.tntcartopt.config.ConfigManager;
import com.tntcartopt.gui.CartOptimizerConfigScreen;
import com.tntcartopt.hud.TntOverlapWarningHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.util.Identifier;

/**
 * Client-only entrypoint. This mod has no "main"/common entrypoint at all -
 * see {@code fabric.mod.json}'s {@code "environment": "client"}, which
 * keeps Fabric Loader from ever loading it on a dedicated server.
 */
public final class TntCartOptimizerClient implements ClientModInitializer {

	public static final String MOD_ID = "tntcartopt";

	private static KeyMapping openConfigKey;

	@Override
	public void onInitializeClient() {
		ConfigManager.load();

		KeyMapping.Category category =
				KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

		openConfigKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.tntcartopt.open_config",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_J,
				category
		));

		HudElementRegistry.addLast(
				Identifier.fromNamespaceAndPath(MOD_ID, "tnt_overlap_warning"),
				TntOverlapWarningHud::render
		);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			// Re-evaluate overlap once per tick; the HUD render callback
			// just reads the resulting flag every frame.
			TntOverlapWarningHud.updateState(client);

			while (openConfigKey.consumeClick()) {
				if (client.gui.screen() == null) {
					client.gui.setScreen(new CartOptimizerConfigScreen(null));
				}
			}
		});
	}
}
