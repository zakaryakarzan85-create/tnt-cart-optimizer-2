package com.tntcartopt.gui;

import com.tntcartopt.config.ConfigManager;
import com.tntcartopt.config.ModConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Small settings screen, opened with the J key, for changing the size of
 * the TNT-overlap "!" warning. "+"/"-" adjust the size, Reset restores the
 * default, Done saves and closes.
 */
public class CartOptimizerConfigScreen extends Screen {

	private static final int BUTTON_HEIGHT = 20;

	private final Screen parent;
	private ModConfig config;

	public CartOptimizerConfigScreen(Screen parent) {
		super(Component.translatable("tntcartopt.config.title"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		this.config = ConfigManager.get();

		int centerX = this.width / 2;
		int rowY = this.height / 2 - 10;

		this.addRenderableWidget(
				Button.builder(Component.literal("-"), btn -> adjustScale(-ModConfig.SCALE_STEP))
						.bounds(centerX - 80, rowY, 20, BUTTON_HEIGHT)
						.build()
		);

		this.addRenderableWidget(
				Button.builder(Component.literal("+"), btn -> adjustScale(ModConfig.SCALE_STEP))
						.bounds(centerX + 60, rowY, 20, BUTTON_HEIGHT)
						.build()
		);

		this.addRenderableWidget(
				Button.builder(Component.translatable("tntcartopt.config.reset"), btn -> resetScale())
						.bounds(centerX - 50, rowY + 30, 100, BUTTON_HEIGHT)
						.build()
		);

		this.addRenderableWidget(
				Button.builder(Component.translatable("tntcartopt.config.done"), btn -> this.onClose())
						.bounds(centerX - 50, rowY + 60, 100, BUTTON_HEIGHT)
						.build()
		);
	}

	private void adjustScale(float delta) {
		this.config.exclamationScale = this.config.clampedScale() + delta;
		this.config.exclamationScale = this.config.clampedScale();
	}

	private void resetScale() {
		this.config.exclamationScale = ModConfig.DEFAULT_SCALE;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);

		// Minecraft doesn't have a built-in "label" widget, so the current
		// size is drawn by hand just above the +/- row.
		String sizeLabel = String.format("Warning size: %.1fx", this.config.clampedScale());
		int labelWidth = this.font.width(sizeLabel);
		int centerX = this.width / 2;
		int rowY = this.height / 2 - 10;

		graphics.text(this.font, sizeLabel, centerX - labelWidth / 2, rowY - this.font.lineHeight - 10, 0xFFFFFFFF, true);
	}

	@Override
	public void onClose() {
		ConfigManager.save();
		this.minecraft.gui.setScreen(this.parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
