package com.tntcartopt.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Everything this mod needs to answer "is this a TNT Minecart?" lives here,
 * on purpose: the placement-delay mixin and the overlap-warning HUD both
 * call into this class instead of duplicating the check, so normal
 * minecarts (and every other item/entity) are never touched by either
 * feature.
 */
public final class TntMinecartUtil {

	private TntMinecartUtil() {
	}

	/**
	 * True only for the TNT Minecart item ({@code minecraft:tnt_minecart}).
	 * A plain {@code minecraft:minecart} (or any other item) returns false.
	 */
	public static boolean isTntMinecartStack(ItemStack stack) {
		return stack != null && !stack.isEmpty() && stack.getItem() == Items.TNT_MINECART;
	}

	/** True if the player is currently holding a TNT Minecart in their main hand. */
	public static boolean isHoldingTntMinecart(Player player) {
		return player != null && isTntMinecartStack(player.getMainHandItem());
	}

	/** True only for an actual TNT Minecart entity in the world. */
	public static boolean isTntMinecartEntity(Entity entity) {
		return entity instanceof MinecartTNT;
	}
}
