package com.tntcartopt.config;

/**
 * Plain data holder for this mod's settings, serialized to/from JSON as-is.
 * Keep this class free of logic beyond the bounds check below so Gson can
 * (de)serialize it directly.
 */
public class ModConfig {

	/** Smallest allowed "!" scale. 1.0 = the font's normal size. */
	public static final float MIN_SCALE = 1.0f;

	/** Largest allowed "!" scale. */
	public static final float MAX_SCALE = 15.0f;

	/** Scale used the first time the mod runs, and by the Reset button. */
	public static final float DEFAULT_SCALE = 5.0f;

	/** How much each press of "+" / "-" changes the scale by. */
	public static final float SCALE_STEP = 0.5f;

	public float exclamationScale = DEFAULT_SCALE;

	/** Returns {@link #exclamationScale} clamped into the supported range. */
	public float clampedScale() {
		if (exclamationScale < MIN_SCALE) {
			return MIN_SCALE;
		}
		if (exclamationScale > MAX_SCALE) {
			return MAX_SCALE;
		}
		return exclamationScale;
	}
}
