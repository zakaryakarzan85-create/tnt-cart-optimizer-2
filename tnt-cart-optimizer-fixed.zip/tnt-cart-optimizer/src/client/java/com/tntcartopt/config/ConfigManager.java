package com.tntcartopt.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Reads and writes {@code config/tntcartopt.json}. Call {@link #load()}
 * once during client init, then use {@link #get()} everywhere else; call
 * {@link #save()} whenever a setting changes.
 */
public final class ConfigManager {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final String FILE_NAME = "tntcartopt.json";

	private static ModConfig config = new ModConfig();

	private ConfigManager() {
	}

	/** The currently loaded settings. Never null. */
	public static ModConfig get() {
		return config;
	}

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	/**
	 * Loads settings from disk, creating a default config file the first
	 * time the mod runs. Safe to call even if the file is missing or
	 * corrupt: this always leaves {@link #get()} pointing at a usable
	 * config.
	 */
	public static void load() {
		Path path = configPath();

		if (!Files.exists(path)) {
			config = new ModConfig();
			save();
			return;
		}

		try (Reader reader = Files.newBufferedReader(path)) {
			ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
			config = (loaded != null) ? loaded : new ModConfig();
		} catch (IOException | RuntimeException e) {
			// Corrupt or unreadable config file: fall back to defaults
			// rather than failing to start the client.
			config = new ModConfig();
		}

		// Guard against a hand-edited file putting the value out of range.
		config.exclamationScale = config.clampedScale();
	}

	/** Writes the current settings to disk. Failures are non-fatal. */
	public static void save() {
		Path path = configPath();
		try {
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path)) {
				GSON.toJson(config, writer);
			}
		} catch (IOException e) {
			// Not being able to persist settings shouldn't crash the game;
			// the in-memory value keeps working for the rest of the session.
		}
	}
}
