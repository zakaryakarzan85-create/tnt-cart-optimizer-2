package com.tntcartopt.mixin;

import com.tntcartopt.util.TntMinecartUtil;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Client-side-only placement optimization for TNT Minecarts.
 *
 * <p>Background: independently of anything the server checks, the vanilla
 * client keeps its own short cooldown ({@code rightClickDelayTimer}) that
 * blocks the next right-click "use item" interaction for a few ticks after
 * the previous one. It exists so that holding down the mouse button doesn't
 * get treated as several rapid clicks (e.g. placing a whole stack of blocks
 * in one held click). On a connection with real ping, that self-imposed
 * client pacing is added on top of network latency, so a player who is
 * genuinely clicking once per cart still feels extra, unnecessary delay
 * between placements.
 *
 * <p>This mixin only ever shortens that purely-client-side timer, and only
 * while the currently held item is a TNT Minecart (see
 * {@link TntMinecartUtil#isHoldingTntMinecart}); every other item, including
 * the plain Minecart, keeps the untouched vanilla timing. Nothing here
 * changes what packet is sent, adds extra packets, or affects whether the
 * server accepts a placement — the server remains fully authoritative and
 * simply receives the next legitimate click sooner instead of having it
 * held back by client UI pacing.
 *
 * <p>Verification note: this targets {@code Minecraft#tick()}, the
 * per-client-tick method, and the {@code rightClickDelayTimer} field — both
 * long-standing, stable names in Minecraft's own client code. Because
 * Minecraft 26.2 is very recent, it's worth confirming both names against
 * your local generated sources (Loom's {@code genSources} task) the first
 * time you build; see the README for what to do if either name has moved.
 */
@Mixin(Minecraft.class)
public abstract class MinecraftClientMixin {

	@Shadow
	private int rightClickDelayTimer;

	@Inject(method = "tick", at = @At("HEAD"))
	private void tntcartopt$reduceDelayForTntMinecart(CallbackInfo ci) {
		if (this.rightClickDelayTimer <= 0) {
			return;
		}

		var player = Minecraft.getInstance().player;
		if (player != null && TntMinecartUtil.isHoldingTntMinecart(player)) {
			this.rightClickDelayTimer = 0;
		}
	}
}
