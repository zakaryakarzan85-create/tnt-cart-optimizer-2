package com.tntcartopt.hud;

import com.tntcartopt.config.ConfigManager;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Detects when 2+ TNT Minecarts occupy essentially the same spot and, while
 * that's true, draws a large "!" in the center of the screen. Purely
 * visual: no chat messages, no sounds, no particles.
 */
public final class TntOverlapWarningHud {

	/**
	 * How close together (in blocks) two TNT Minecarts have to be to count
	 * as "the same place". Change this single constant to make the warning
	 * more or less sensitive.
	 */
	public static final double OVERLAP_DISTANCE_THRESHOLD = 0.5D;

	/** How far around the player to look for TNT Minecarts, in blocks. */
	private static final double SEARCH_RADIUS = 64.0D;

	private static final double OVERLAP_DISTANCE_THRESHOLD_SQ =
			OVERLAP_DISTANCE_THRESHOLD * OVERLAP_DISTANCE_THRESHOLD;

	// ARGB (not RGB) - Minecraft 1.21.6+ text rendering ignores the alpha
	// channel only if it's missing entirely, so this must stay 0xFF______.
	private static final int WARNING_COLOR = 0xFFFF3B30;
	private static final String WARNING_TEXT = "!";

	private static boolean overlapping = false;

	private TntOverlapWarningHud() {
	}

	/**
	 * Re-checks every currently loaded TNT Minecart for overlap. Intended
	 * to be called once per client tick, not once per frame - the pairwise
	 * check is cheap for the handful of carts a player would normally have
	 * out, but there's no reason to redo it more often than the game state
	 * actually changes.
	 */
	public static void updateState(Minecraft client) {
		if (client.level == null || client.player == null) {
			overlapping = false;
			return;
		}

		AABB searchBox = client.player.getBoundingBox().inflate(SEARCH_RADIUS);
		List<MinecartTNT> carts = client.level.getEntitiesOfClass(MinecartTNT.class, searchBox);

		overlapping = anyPairOverlaps(carts);
	}

	private static boolean anyPairOverlaps(List<MinecartTNT> carts) {
		for (int i = 0; i < carts.size(); i++) {
			MinecartTNT a = carts.get(i);
			for (int j = i + 1; j < carts.size(); j++) {
				MinecartTNT b = carts.get(j);
				if (a.distanceToSqr(b) <= OVERLAP_DISTANCE_THRESHOLD_SQ) {
					return true;
				}
			}
		}
		return false;
	}

	/** Registered with {@code HudElementRegistry}; draws only while overlapping is true. */
	public static void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		if (!overlapping) {
			return;
		}

		Minecraft client = Minecraft.getInstance();
		float scale = ConfigManager.get().clampedScale();

		int centerX = client.getWindow().getGuiScaledWidth() / 2;
		int centerY = client.getWindow().getGuiScaledHeight() / 2;

		var matrices = graphics.pose();
		matrices.pushMatrix();
		matrices.translate(centerX, centerY);
		matrices.scale(scale, scale);

		int textWidth = client.font.width(WARNING_TEXT);
		graphics.text(
				client.font,
				WARNING_TEXT,
				-textWidth / 2,
				-client.font.lineHeight / 2,
				WARNING_COLOR,
				true
		);

		matrices.popMatrix();
	}
}
